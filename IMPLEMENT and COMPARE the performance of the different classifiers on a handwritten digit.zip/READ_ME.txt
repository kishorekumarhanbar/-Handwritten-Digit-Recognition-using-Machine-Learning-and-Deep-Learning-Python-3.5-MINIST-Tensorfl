
Libraries:
all libraries are used in a windows systems 
1) pip install (libraries used)


import pandas as pd
import numpy as np 
import seaborn as sns
import matplotlib.pyplot as plt
%matplotlib inline
import tensorflow as tf
import sklearn as sk

Dataset Used
http://yann.lecun.com/exdb/mnist/

Algorithms Used
3.1 SGD Classifier
3.2 Random Forest Classifier
3.3 SVM Classifier
3.4 Decision Tree Classifier
3.5 K Nearest Neighbor
3.6 Radial Basis Function Calssifier 
3.7 One-hidden Layer Fully Connected Multilayer Neural Network
3.8 Two-hidden Layer Fully Connected Multilayer Neural Network 
